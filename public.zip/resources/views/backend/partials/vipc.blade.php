
<div class="row mt-15">
	<div class="col-md-12">
		<div class="alert alert-danger" role="alert">
			<span>Thank you!</span>
		</div>
	</div>
</div>
