<div class="dashbord-sidebar">
	<div class="profile-info">
		<?php if(isset(Auth::user()->id)): ?>
		<div class="avatar"><?php echo e(sub_str(Auth::user()->name, 0,1)); ?></div>
		<h5><?php echo e(Auth::user()->name); ?></h5>
		<p><?php echo e(Auth::user()->email); ?></p>
		<?php endif; ?>
	</div>
	<div class="sidebar-nav">
		<ul>
			<li><a href="<?php echo e(route('frontend.my-dashboard')); ?>"><i class="bi bi-speedometer"></i><?php echo e(__('My Dashboard')); ?></a></li>
			<li><a href="<?php echo e(route('frontend.my-booking')); ?>"><i class="bi bi-journal-text"></i><?php echo e(__('My Booking')); ?></a></li>
			<li><a href="<?php echo e(route('frontend.my-profile')); ?>"><i class="bi bi-person"></i><?php echo e(__('Profile')); ?></a></li>
			<li><a href="<?php echo e(route('frontend.change-password')); ?>"><i class="bi bi-lock"></i><?php echo e(__('Change Password')); ?></a></li>
			<?php if(isset(Auth::user()->role_id)): ?>
				<?php if(Auth::user()->role_id == 1): ?>
					<li><a href="<?php echo e(route('backend.dashboard')); ?>"><i class="bi bi-reply"></i><?php echo e(__('Goto Backend Dashboard')); ?></a></li>
				<?php elseif(Auth::user()->role_id == 3): ?> 
					<li><a href="<?php echo e(route('receptionist.dashboard')); ?>"><i class="bi bi-reply"></i><?php echo e(__('Goto Backend Dashboard')); ?></a></li>
				<?php endif; ?>
			<?php endif; ?>
			<li><a  href="<?php echo e(route('logout')); ?>"
				onclick="event.preventDefault();
				document.getElementById('my-logout-form').submit();"><i class="bi bi-box-arrow-right"></i><?php echo e(__('Logout')); ?></a>
				<form id="my-logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
					<?php echo csrf_field(); ?>
				</form>
			</li>
		</ul>
	</div>
</div><?php /**PATH E:\xampp\htdocs\relaxly\relaxly-v1.0.0\resources\views/frontend/partials/my-dashbord-sidebar.blade.php ENDPATH**/ ?>